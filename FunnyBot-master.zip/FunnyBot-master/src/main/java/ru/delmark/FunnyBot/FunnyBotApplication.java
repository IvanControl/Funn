package ru.delmark.FunnyBot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunnyBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(FunnyBotApplication.class, args);
	}

}
